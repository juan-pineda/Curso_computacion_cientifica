import numpy as np

print("La calculadora está trabajando")
filename = "temperatura_mensual.dat"

try:
	datos = np.loadtxt(filename)
except:
	print("No es posible cargar la tabla de temperaturas")

temp_promedio = np.mean(datos)

np.savetxt("resultados.dat",[temp_promedio])


