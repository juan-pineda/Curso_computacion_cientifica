import numpy as np
from pylab import *

print("Gráfico de resultados finales")

filename = "temperatura_mensual.dat"

try:
	datos_2009 = np.loadtxt("resultados_2009.dat")
except:
	print("No es posible cargar los resultados de 2009")


try:
    datos_2010 = np.loadtxt("resultados_2010.dat")
except:
    print("No es posible cargar los resultados de 2010")

try:
    datos_2011 = np.loadtxt("resultados_2011.dat")
except:
    print("No es posible cargar los resultados de 2011")


try:
    datos_2012 = np.loadtxt("resultados_2012.dat")
except:
    print("No es posible cargar los resultados de 2012")


plot(datos_2009,"o-g",alpha=0.5,label = "2009")
plot(datos_2010,"o-r",alpha=0.5,label = "2010")
plot(datos_2011,"o-b",alpha=0.5,label = "2011")
plot(datos_2012,"o-k",alpha=0.5,label = "2012")
xlabel("meses")
ylabel("Temperatura media [K]")
grid()
legend()
savefig("Temperatura_Bucaramanga.jpg")
show()



